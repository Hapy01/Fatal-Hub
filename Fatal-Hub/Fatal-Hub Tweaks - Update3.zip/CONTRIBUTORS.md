# Universal Bypass Contributors

Thanks to everyone who helps make Universal Bypass:

- The [code contributors](https://github.com/Sainan/Universal-Bypass/graphs/contributors) right here at Github.
- All the translators into various languages over at [Crowdin](https://crowdin.com/project/bypass).

## Libraries used by Universal Bypass

- Universal Bypass uses [UIkit](https://getuikit.com/) for its design.
- The custom bypass editor is powered by [Ace](https://ace.c9.io/).
